# -*- codeing = utf-8 -*-
# @Author : wyh
# @Software : PyCharm
import numpy as np
from scipy.spatial.distance import cdist


def quickshift(data, kernel_size, max_distance):
    num_points, num_features = data.shape
    kernel = np.eye(num_features) * kernel_size

    # Calculate pairwise distances between points
    pairwise_distances = cdist(data, data)

    # Initialize cluster assignments and distances
    cluster_assignments = np.arange(num_points)
    distances = np.zeros(num_points)

    # Main loop for QuickShift algorithm
    for _ in range(max_distance):
        for i in range(num_points):
            # Find neighbors within the kernel size
            neighbors = np.where(pairwise_distances[i] < kernel_size)[0]

            # Find the neighbor with the maximum similarity
            max_similarity = -np.inf
            max_similarity_idx = i
            for neighbor in neighbors:
                similarity = kernel.dot(data[neighbor] - data[i])
                if similarity > max_similarity:
                    max_similarity = similarity
                    max_similarity_idx = neighbor

            # Assign the cluster and update distance
            cluster_assignments[i] = cluster_assignments[max_similarity_idx]
            distances[i] = max_similarity

    return cluster_assignments, distances