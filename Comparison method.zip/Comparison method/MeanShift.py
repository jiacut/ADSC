# -*- codeing = utf-8 -*-
# @Author : wyh
# @Software : PyCharm
"""
meanshift聚类算法
核心思想：
寻找核密度极值点并作为簇的质心，然后根据最近邻原则将样本点赋予质心
"""
# 导入相关模块和导入数据集
import numpy as np
from sklearn.cluster import MeanShift, estimate_bandwidth
from sklearn.datasets import make_blobs
# 生成样本数据
file_name = "flame"
with open(file_name + ".txt", "r", encoding="utf-8") as f:
    lines = f.read().splitlines()
lines = [line.split("\t")[:-1] for line in lines]
X = np.array(lines).astype(np.float32)


#centers = [[1, 1], [-1, -1], [1, -1]]
#X, _ = make_blobs(n_samples=10000, centers=centers, cluster_std=0.6)
#es_bandwidth = estimate_bandwidth(X,quantile=0.2, n_samples= 500)
'''
estimate_bandwidth()用于生成mean-shift窗口的尺寸，
其参数的意义为：从X中随机选取500个样本，
计算每一对样本的距离，然后选取这些距离的0.2分位数作为返回值
'''
#MS = MeanShift(bandwidth=es_bandwidth)
MS=MeanShift()
MS.fit(X)
labels = MS.labels_
cluster_centers=[[7.11,3.7],[7.42,12.23],[17.36,7.29],[9.16,22.81],[22.24,23.89],[33.36,21.56],[32.34,8.82]]
#cluster_centers = MS.cluster_centers_
uni_labels = np.unique(labels)
n_clusters_ = len(uni_labels)
import matplotlib.pyplot as plt
from itertools import cycle



# 对算法聚类结果进行可视化
colors = cycle('bgrcmykbgrcmykbgrcmykbgrcmyk')
for k, col in zip(range(n_clusters_), colors):
    my_members = labels == k
    cluster_center = cluster_centers[k]
    plt.plot(X[my_members, 0], X[my_members, 1], col + '.')
    plt.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col,
             markeredgecolor='k', markersize=14)
plt.show()
plt.savefig("picture")
